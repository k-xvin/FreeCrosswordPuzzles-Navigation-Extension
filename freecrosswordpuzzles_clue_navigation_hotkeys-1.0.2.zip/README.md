# Overview
This extension adds tab key shortcuts to freecrosswordpuzzles.com.au, similar to the shortcuts found in the nytimes crosswords.

* Tab to move forward a clue
* Shift + Tab to move backwards a clue


# Build for Firefox
`web-ext build -o -a .`