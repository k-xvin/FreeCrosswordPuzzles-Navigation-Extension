# Overview
Adds keyboard navigation hotkeys to crosswords on https://freecrosswordpuzzles.com.au.
* Tab/Enter to move forward a clue
* Shift + Tab/Enter to move backward a clue


# Build for Firefox
`web-ext build -o -a .`