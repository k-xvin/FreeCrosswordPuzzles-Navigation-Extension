# Overview
This extension adds tab key shortcuts to freecrosswordpuzzles.com.au, similar to the shortcuts found in the nytimes crosswords.

* Tab to move forward a clue
* Shift + Tab to move backwards a clue

# Installation
1. Download the .zip file 
3. Load the folder into your browser's extension area (you may need to be in developer mode)
